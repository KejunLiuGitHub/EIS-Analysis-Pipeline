EC-LAB SETTING FILE

Number of linked techniques : 1

EC-LAB for windows v11.62 (software)
Internet server v27.00 (firmware)
Command interpretor v12.02 (firmware)

Filename : C:\Users\29607\Desktop\data\ls\???\26.5.8\GPE_h4_201.mps

Device : SP-300
Electrode connection : standard
Potential control : Ewe
Ewe ctrl range : min = -10.00 V, max = 10.00 V
Ewe,I filtering : 50 kHz
Safety Limits :
	Do not start on E overload
Channel : Grounded
Electrode material : 
Initial state : 
Electrolyte : 
Comments : 
Cable : standard
Electrode surface area : 0.001 cm2
Characteristic mass : 0.001 g
Equivalent Weight : 0.000 g/eq.
Density : 0.000 g/cm3
Volume (V) : 0.001 cm3
Record EIS quality indicators
Cycle Definition : Charge/Discharge alternance
Turn to OCV between techniques

Technique : 1
Potentio Electrochemical Impedance Spectroscopy
Mode                Single sine         
E (V)               0.0000              
vs.                 Eoc                 
tE (h:m:s)          0:00:0.0000         
record              0                   
dI                  0.000               
unit dI             mA                  
dt (s)              0.000               
fi                  7.000               
unit fi             MHz                 
ff                  1.000               
unit ff             Hz                  
Nd                  6                   
Points              per decade          
spacing             Logarithmic         
Va (mV)             100.0               
pw                  0.10                
Na                  2                   
corr                0                   
E range min (V)     -10.000             
E range max (V)     10.000              
I Range             Auto                
Bandwidth           8                   
nc cycles           0                   
goto Ns'            0                   
nr cycles           0                   
inc. cycle          0                   
